package co.edu.eafit.protobootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//Prueba de integración
@SpringBootTest
class ProtobootappApplicationTests {

    //Esta prueba falla si el application context no puede iniciar, pero no es habitual
    @Test
    void contextLoads() {
    }

}
