package co.edu.eafit.protobootapp;

//This is a simple calculator class.
public class Calculadora {

    public Double cuadrado(Double numero) {
        return numero * numero;
    }
    
    public Double cubo(Double numero) {
        return numero * numero * numero;
    }
}
